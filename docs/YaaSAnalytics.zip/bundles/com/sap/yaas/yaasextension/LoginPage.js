//jQuery.sap.require("com.sap.yaas.yaasextension.YaasSettings");

define(function() {
	"use strict";
	var gUsername = "";
	var gProxy = ""
	var gDataSetName = "";
	var selectedScopes = [];
	var oVL = null;
	var selectAllCheckbox = null;
	var csspath = jQuery.sap.getModulePath("com.sap.yaas.yaasextension",
			"/css/Style.css");
	jQuery.sap.includeStyleSheet(csspath);
	/**
	 * Utility functions
	 */

	function constructScopeStr() {
		var scopeList = "";
		selectedScopes = selectedScopes || [];
		if (selectedScopes) {
			selectedScopes.forEach(function(scope) {

				if (scope.selected) {
					scopeList += scope.id + " ";
				}
			});
		}

		scopeList = scopeList.trim();

		sap.ui.getCore().getModel().setProperty("/scopeList", scopeList);
	}

	/**
	 * UI code starts here
	 */

	var LoginPage = function(acquisitionState, oDeferred, fServiceCall,
			workflow) {

		if ((workflow === "CREATE" && acquisitionState.info == "")
				|| (workflow === "EDIT") || workflow === "REFRESH_WITH_PROMPTS") {

			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);

			if ((workflow === "EDIT" || workflow === "REFRESH_WITH_PROMPTS")
					&& acquisitionState.info) {
				var jsonInfo = JSON.parse(acquisitionState.info);
				oModel.setProperty("/selectedScopes", jsonInfo.scope);
			}

			sap.ui.getCore().setModel(oModel);

			var oMatrix = new sap.ui.commons.layout.MatrixLayout({
				layoutFixed : true,
				width : '500px',
				columns : 4
			});
			oMatrix.setWidths('200px', '300px');

			var oImage = new sap.ui.commons.Image({
				src : "/img/yaas_logo_2/png"
			});

			var hText = new sap.ui.commons.layout.MatrixLayoutCell({
				colSpan : 4
			});
			hText.addContent(new sap.ui.commons.TextView({
				text : 'YaaS Analytics',
				design : sap.ui.commons.TextViewDesign.H1
			}));

			oMatrix.createRow(oImage, hText)

			var dLayout = new sap.ui.commons.layout.MatrixLayout({
				layoutFixed : true,
				columns : 2,
				width : "100%",
				widths : [ "20%", "80%" ]
			});

			var dLayout4 = new sap.ui.commons.layout.MatrixLayout({
				layoutFixed : true,
				columns : 4,
				width : "570px",
				widths : [ "10%", "40%", "10%", "40%" ]
			});

			var usernameTxt = new sap.ui.commons.TextField({
				width : '100%',
				height : "25%",
				value : "",
				tooltip : "YaaS Email Address",
				required : true,
				// enabled : workflow === "CREATE",
				change : function() {
					if (this.getValue() === "") {
						this.setValueState(sap.ui.core.ValueState.Error);
					} else {
						this.setValueState(sap.ui.core.ValueState.None);
					}

				}

			});

			usernameTxt.attachBrowserEvent('keyup', function(e) { // check key
				// code
				if (e.which == 13)
					NextButton.firePress();
			});

			usernameTxt.setPlaceholder("me@sap.com")
			// usernameTxt.setValueState(sap.ui.core.ValueState.Error);

			var usernameLbl = new sap.ui.commons.Label({
				text : "Username:",
				labelFor : usernameTxt
			});

			dLayout.createRow({
				height : "100%"
			}, usernameLbl, usernameTxt);

			var passwordTxt = new sap.ui.commons.PasswordField({
				width : '100%',
				height : "25%",
				value : "",
				tooltip : "YaaS Login Password",
				required : true,
				change : function() {
					if (this.getValue() === "") {
						this.setValueState(sap.ui.core.ValueState.Error);
					} else {
						this.setValueState(sap.ui.core.ValueState.None);
					}

				}

			});

			passwordTxt.attachBrowserEvent('keyup', function(e) { // check key
				// code
				if (e.which == 13)
					NextButton.firePress();
			});

			passwordTxt.setPlaceholder("Password");

			var passwordLbl = new sap.ui.commons.Label({
				text : "Password:",
				labelFor : passwordTxt
			});

			dLayout.createRow({
				height : "100%"
			}, passwordLbl, passwordTxt);

			var proxyTxt = new sap.ui.commons.TextField({
				width : '100%',
				height : "25%",
				tooltip : "Proxy Details",
				value : ""
			});
			proxyTxt.attachBrowserEvent('keyup', function(e) { // check key
				// code
				if (e.which == 13)
					NextButton.firePress();
			});
			proxyTxt.setPlaceholder("proxy:8080");

			var proxyLbl = new sap.ui.commons.Label({
				text : "Proxy:",
				labelFor : proxyTxt
			});

			dLayout.createRow({
				height : "100%"
			}, proxyLbl, proxyTxt);

			/*
			 * Button press events
			 */
			var buttonCancelPressed = function() {
				oDeferred.reject(); // promise fail
				dialog.close(); // dialog is hoisted from below
			};

			var buttonPreviousPressed = function() {
				// oDeferred.reject(); //promise fail
				// dialog.close();
			};

			var PreviousButton = new sap.ui.commons.Button({
				press : [ buttonPreviousPressed, this ],
				text : "Previous",
				tooltip : "Previous",
				enabled : false
			}).addStyleClass(sap.ui.commons.ButtonStyle.Default);

			function validateTextFieldValues() {

				// this function checks its value, you can insert more checks on
				// the
				// value
				if (passwordTxt.getValue() == ""
						|| usernameTxt.getValue() == "") {
					sap.ui.commons.MessageBox.show(
							"Please enter mandatory information",
							sap.ui.commons.MessageBox.Icon.ERROR, "Error");
				}

				// ...
				// the same for the other fields
			}

			var NextButton = new sap.ui.commons.Button(
					{
						press : [

								function() {
									var loginDialog = sap.ui.getCore().byId(
											"loginDialog");
									if (loginDialog != undefined)
										loginDialog.setBusy(true);
									var request = {};
									request.requestName = "login";
									request.requestParams = [];
									var requestParam1 = {};
									requestParam1.requestParamName = "username";
									requestParam1.requestParamValue = usernameTxt
											.getValue();
									request.requestParams.push(requestParam1);
									var requestParam2 = {};
									requestParam2.requestParamName = "password";
									requestParam2.requestParamValue = passwordTxt
											.getValue();
									request.requestParams.push(requestParam2);
									var requestParam3 = {};
									requestParam3.requestParamName = "proxy";
									requestParam3.requestParamValue = proxyTxt
											.getValue();
									request.requestParams.push(requestParam3);
									gUsername = usernameTxt.getValue();
									gProxy = proxyTxt.getValue();

									fServiceCall(
											JSON.stringify(request),
											function(response) {
												/*
												 * sap.ui.commons.MessageBox.alert(response);
												 */
												if (response == "true") {
													var info = {};
													info.username = usernameTxt
															.getValue();
													info.proxy = proxyTxt
															.getValue();
													if (acquisitionState.info) {

														var json = JSON
																.parse(acquisitionState.info);

														if (json.username == info.username) {
															info.project = json.project;
															info.packageName = json.packageName;
															info.url = json.url;
															info.scope = json.scope;
															info.dataset = json.dataset;

															info.header = json.header;
															info.queryParameters = json.queryParameters;
															info.clientId = json.clientId;
														} else {
															info.dataset = json.dataset;
														}
													}

													acquisitionState.info = JSON
															.stringify(info);
													var controller1 = YaasSettings(
															acquisitionState,
															oDeferred,
															fServiceCall,
															workflow);
												} else {
													sap.ui.commons.MessageBox
															.show(
																	"Login Failed. Please enter valid YaaS Credentials.",
																	sap.ui.commons.MessageBox.Icon.ERROR,
																	"Error");
												}
												var loginDialog = sap.ui
														.getCore().byId(
																"loginDialog");
												if (loginDialog != undefined)
													loginDialog.setBusy(false);
											},
											function(actionRequired,
													errorMessage,
													fullErrorObject) {
												sap.ui.commons.MessageBox
														.show(
																errorMessage,
																sap.ui.commons.MessageBox.Icon.ERROR);
												var loginDialog = sap.ui
														.getCore().byId(
																"loginDialog");
												if (loginDialog != undefined)
													loginDialog.setBusy(false);
											});
								}, this ],

						text : "Next",
						tooltip : "Next"

					}).setStyle(sap.ui.commons.ButtonStyle.Accept);

			var cancelButton = new sap.ui.commons.Button({
				press : [ buttonCancelPressed, this ],
				text : "Cancel",
				tooltip : "Cancel"
			}).addStyleClass(sap.ui.commons.ButtonStyle.Default);

			var onClosed = function() {
				if (oDeferred.state() === "pending") {
					this.destroy();
					oDeferred.reject();
				}
			};

			/*
			 * Modify controls based on acquisitionState
			 */
			var envProperties = acquisitionState.envProps;
			if (acquisitionState.info) {
				var info = JSON.parse(acquisitionState.info);
				usernameTxt.setValue(info.username);
				passwordTxt.setValue(info.password);
				proxyTxt.setValue(info.proxy);

			}

			/*
			 * Create the dialog
			 */
			var dialog = sap.ui.getCore().byId("loginDialog");
			if (dialog == undefined)
				dialog = new sap.ui.commons.Dialog("loginDialog",
						{
							width : "500px",
							height : "300px",
							modal : true,
							resizable : false,
							closed : function() {
								this.destroy();
								oDeferred.reject();
							},
							content : [ dLayout, dLayout4 ],
							buttons : [ /* PreviousButton, */NextButton,
									cancelButton ]
						});

			this.showDialog = function() {
				dialog.open();
			};

			LoginPage.prototype.getIconyaas_logo_2 = function() {
				return "/img/yaas_logo_2.png";
			};
			dialog.setTitle("YaaS Analytics");
			dialog.open();
		} else {
			var oModel = sap.ui.getCore().getModel();
			var jsonInfo = JSON.parse(acquisitionState.info);
			oModel.setProperty("/selectedScopes", jsonInfo.scope);

			var controller1 = YaasSettings(acquisitionState, oDeferred,
					fServiceCall, workflow);

		}

	};
	var YaasSettings = function(acquisitionState, oDeferred, fServiceCall,
			workflow) {
		// / TODO Write GetProjects logic.
		var request = {};
		request.requestName = "projects";
		request.requestParams = [];
		var oModel = sap.ui.getCore().getModel();
		oModel.setProperty('/projectList', [ {
			name : 'Select'
		} ]);
		oModel.setProperty('/packageList', [ {
			name : 'Select'
		} ]);

		fServiceCall(JSON.stringify(request), function(response) {
			var oModel = sap.ui.getCore().getModel();
			if (response != null && response != "") {

				var json = JSON.parse(response);

				json.unshift({
					id : 'default',
					name : 'Select'
				})
				oModel.setProperty("/projectList", json);
				sap.ui.getCore().setModel(oModel);
				// manageScopeButton.setEnabled(false);

			}
			var settingsDialog = sap.ui.getCore().byId("yaasSettingsDialog");
			if (settingsDialog != undefined)
				settingsDialog.setBusy(false);

			if (workflow === "EDIT" || workflow === "REFRESH_WITH_PROMPTS") {
				var infoJSON = JSON.parse(acquisitionState.info);
				var selectedProjectName = infoJSON.project;
				var projectItems = projectTxt.getItems();
				for (var i = 0; i < projectItems.length; i++) {
					if (projectItems[i].getKey() == selectedProjectName) {
						var map = {};
						map.initialValue = "";
						map.selectedItem = projectItems[i];
						projectTxt.setSelectedKey(selectedProjectName);
						projectTxt.fireChange(map);
					}
				}
			}
			if (oModel.getProperty("/selectedProject") != undefined) {
				var map = {};
				map.initialValue = "";
				map.selectedItem = oModel.getProperty("/selectedProject");
				projectTxt.setSelectedKey(oModel
						.getProperty("/selectedProject").getText());
				projectTxt.fireChange(map);
			}
			if (oModel.getProperty("/selectedScopes") != undefined)
				oModel.setProperty("/scopeList", oModel
						.getProperty("/selectedScopes"));

		}, function(actionRequired, errorMessage, fullErrorObject) {
			sap.ui.commons.MessageBox.alert(errorMessage);
			var settingsDialog = sap.ui.getCore().byId("yaasSettingsDialog");
			if (settingsDialog != undefined)
				settingsDialog.setBusy(false);
		});

		var dLayout = new sap.ui.commons.layout.MatrixLayout({
			layoutFixed : true,
			columns : 3,
			width : "570px",
			widths : [ "20%", "70%", "5%" ]
		});

		var dataSetNameTxt = new sap.ui.commons.TextField({
			width : '100%',
			value : "",
			required : true,
			tooltip : "Name of the dataset to be created",
			enabled : workflow === "CREATE"
		});
		dataSetNameTxt.attachBrowserEvent('keyup', function(e) { // check key
			// code
			if (e.which == 13)
				FinalNextButton.firePress();
		});

		dataSetNameTxt.setPlaceholder("New Dataset");

		var dataSetNameLbl = new sap.ui.commons.Label({
			text : "Dataset Name",
			labelFor : dataSetNameTxt
		});

		dLayout.createRow({
			height : "40px"
		}, dataSetNameLbl, dataSetNameTxt);

		var projectList = new sap.ui.core.ListItem({
			text : "{name}",
			key : "{id}",
			tooltip : "YaaS Login Password"
		});

		var projectTxt = new sap.ui.commons.DropdownBox(
				{
					width : '100%',
					value : "",
					tooltip : "YaaS Project/Site",
					change : function(oEvent) {
						scopeTxt.setEnabled(false);
						var oModel = sap.ui.getCore().getModel();

						oModel.setProperty('/selectedProject',
								oEvent.mParameters.selectedItem);

						if (oEvent.mParameters.selectedItem.getText() === 'Select') {
							oModel.setProperty('/packageList', [ {
								name : 'Select'
							} ]);
							packageTxt.setEnabled(false);
							manageScopeButton.setEnabled(false);
							// manageScopeButton.setTooltip("Select Project & Package");
							scopeTxt.setEnabled(true);
							selectedScopes = [];

						} else {
							scopeTxt.setEnabled(true);

							// manageScopeButton.setTooltip("Select Package")
							var projectList = oModel
									.getProperty("/projectList");
							packageTxt.setEnabled(true);

							for (i = 0; i < projectList.length; i++) {
								if (projectList[i].id == oEvent.oSource
										.getSelectedKey()) {
									var packageArr = projectList[i].packages;
									if (!packageArr) {
										packageArr = [];
									}
									packageArr = packageArr.slice();
									packageArr.unshift({
										name : 'Select'
									});
									oModel.setProperty("/packageList",
											packageArr)
									selectedScopes = [];
									manageScopeButton.setEnabled(false);
								}
							}
							if (workflow === "EDIT"
									|| workflow === "REFRESH_WITH_PROMPTS") {
								var infoJSON = JSON
										.parse(acquisitionState.info);
								var selectedPackageName = infoJSON.packageName;
								var packageItems = packageTxt.getItems();
								for (var i = 0; i < packageItems.length; i++) {
									if (packageItems[i].getKey() == selectedPackageName) {
										var map = {};
										map.initialValue = "";
										map.selectedItem = packageItems[i];
										packageTxt
												.setSelectedKey(selectedPackageName);
										packageTxt.fireChange(map);
									}
								}
							}

							if (oModel.getProperty("/selectedPackage") != undefined) {
								var map = {};
								map.initialValue = "";
								map.selectedItem = oModel
										.getProperty("/selectedPackage");
								packageTxt.setSelectedKey(oModel.getProperty(
										"/selectedPackage").getText());
								packageTxt.fireChange(map);
							}
						}
						constructScopeStr();

					}
				}).bindAggregation("items", "/projectList", projectList);

		var projectLbl = new sap.ui.commons.Label({
			text : "Project",
			labelFor : projectTxt
		});

		dLayout.createRow({
			height : "40px"
		}, projectLbl, projectTxt);

		var packageList = new sap.ui.core.ListItem({
			text : "{name}",
			key : "{name}"
		});

		var packageTxt = new sap.ui.commons.DropdownBox(
				{
					width : '100%',
					value : "",
					tooltip : "YaaS Package is a bundle of services",
					enabled : false,
					change : function(oEvent) {

						var oModel = sap.ui.getCore().getModel();
						var constructScope = false;
						if (oModel.getProperty('/selectedPackage') != oEvent.mParameters.selectedItem)
							constructScope = true;
						oModel.setProperty('/selectedPackage',
								oEvent.mParameters.selectedItem);
						if (oEvent.mParameters.selectedItem.getText() === 'Select') {
							selectedScopes = [];
							manageScopeButton.setEnabled(false);
							scopeTxt.setEnabled(true);
						} else

						{
							scopeTxt.setEnabled(false);
							manageScopeButton.setEnabled(true);
							// manageScopeButton.setTooltip("Manage Scopes")
							var packageList = oModel
									.getProperty("/packageList");

							for (i = 0; i < packageList.length; i++) {
								if (packageList[i].name == oEvent.oSource
										.getSelectedKey()) {
									selectedScopes = $.extend([],
											packageList[i].availableScopes);

								}
							}
							selectedScopes.forEach(function(scope) {
								scope.selected = true;
							});
						}
						if (constructScope)
							constructScopeStr();
					}
				}).bindAggregation("items", "/packageList", packageList);

		var packageLbl = new sap.ui.commons.Label({
			text : "Package",
			labelFor : packageTxt
		});

		dLayout.createRow({
			height : "40px"
		}, packageLbl, packageTxt);

		var URLTxt = new sap.ui.commons.TextField({
			width : '100%',
			required : true,
			tooltip : "YaaS Resource Address"
		});
		URLTxt.attachBrowserEvent('keyup', function(e) { // check key code
			if (e.which == 13)
				FinalNextButton.firePress();
		});
		URLTxt
				.setPlaceholder("https://api.yaas.io/hybris/order/v1/{tenant}/salesorders");

		var URLLbl = new sap.ui.commons.Label({
			text : "URL",
			labelFor : URLTxt
		});

		dLayout.createRow({
			height : "40px"
		}, URLLbl, URLTxt);

		var clientIdTxt = new sap.ui.commons.TextField({
			width : '100%',
			tooltip : "Client Id of the YaaS Application"
		});
		clientIdTxt.attachBrowserEvent('keyup', function(e) { // check key
			// code
			if (e.which == 13)
				FinalNextButton.firePress();
		});
		clientIdTxt.setPlaceholder("client_id");

		var ClientIdLbl = new sap.ui.commons.Label({
			text : "Client Id",
			labelFor : clientIdTxt
		});

		dLayout.createRow({
			height : "40px"
		}, ClientIdLbl, clientIdTxt);

		var scopeSearchText = new sap.ui.commons.Label({
			text : "Scope"
		});

		var scopeTxt = new sap.ui.commons.TextField({
			width : '100%',
			tooltip : "Permissions for the YaaS resource end-point",
			required : true,
			value : {
				parts : [ '/scopeList', '/selectedProject' ],
				formatter : function(scopeListString, selectedProject) {
					if (selectedProject == "Select"
							|| selectedProject == undefined) {
						return "";
					}
					var text = "hybris.tenant=";
					var sProject = selectedProject.getText() === 'Select' ? ''
							: selectedProject.getText();
					// console.log(selectedProject)
					if (scopeListString != "" && scopeListString != undefined
							&& scopeListString.indexOf("hybris.tenant=") > -1)
						finalTxt = scopeListString;
					else {
						var finalTxt = text + sProject + " "
								+ (scopeListString ? scopeListString : '');

					}
					return finalTxt;
				}
			}
		});
		var manageScopeButton = new sap.ui.commons.Button({

			tooltip : "Manage Scopes",
			icon : "sap-icon://edit",
			enabled : false,
			press : function() {

				popUp.open();
				selectAllCheckbox = new sap.ui.commons.CheckBox({
					checked : true,
					change : function() {
						if (selectAllCheckbox.getChecked()) {
							var data = [];
							var selectAll = oVL.getModel().getData();
							oVL.getModel().setData(data);

							selectAll.forEach(function(scope) {
								scope.selected = true;
							});
							oVL.getModel().setData(selectAll);
						}

						else {
							var data = [];
							var deselectAll = oVL.getModel().getData();
							oVL.getModel().setData(data);

							deselectAll.forEach(function(scope) {
								scope.selected = false;
							});
							oVL.getModel().setData(deselectAll);
						}
					}
				});
				var checkboxLayout = new sap.ui.layout.HorizontalLayout();
				var CheckboxLabel = new sap.ui.commons.Label();
				CheckboxLabel.setText("Scopes");
				CheckboxLabel.addStyleClass("CheckboxLabelColor");
				CheckboxLabel.setDesign(sap.ui.commons.LabelDesign.Bold)

				checkboxLayout.addContent(selectAllCheckbox);
				checkboxLayout.addContent(CheckboxLabel);

				oVL = new sap.ui.layout.VerticalLayout();

				var oHL = new sap.ui.layout.HorizontalLayout();
				oHL.addContent(new sap.ui.commons.CheckBox({
					key : " {id}",
					checked : "{selected}",
					change : function() {
						//selectAllCheckbox.setChecked(false);
						var counter = 0;
						var checkScopes = oVL.getModel().getData();
						checkScopes.forEach(function(scope, index) {
							if (scope.selected == false) {
								selectAllCheckbox.setChecked(false);
								return;
							} else {
								counter++;
							}
							if (counter == checkScopes.length) {
								selectAllCheckbox.setChecked(true);
							}
						})
					},

					value : "{description}"
				}));
				oHL.addContent(new sap.ui.commons.Label({

					text : "{id}",
					tooltip : "{description}"
				}).addStyleClass("scopelbl"));

				oVL.bindAggregation("content", {
					path : "/",
					template : oHL
				});

				var oSearch = new sap.ui.commons.SearchField({
					enableListSuggest : false,
					enableClear : true,
					startSuggestion : 0,
					search : function(oEvent) {
						alert(oEvent.getParameter("query"));
					},
					suggest : function(oEvent) {
						updateList(oVL, oEvent.getParameter("value"));
					}
				});

				var vLayout = new sap.ui.layout.VerticalLayout();
				vLayout.addContent(oSearch);
				vLayout.addContent(checkboxLayout);
				vLayout.addContent(oVL);

				var jModel = new sap.ui.model.json.JSONModel();
				jModel.setData(selectedScopes);
				oVL.setModel(jModel);
				popUp.destroyContent();
				popUp.addContent(vLayout);
				var counter = 0;
				var checkScopes = oVL.getModel().getData();
				checkScopes.forEach(function(scope, index) {
					if (scope.selected == false) {
						selectAllCheckbox.setChecked(false);
						return;
					} else {
						counter++;
					}
					if (counter == checkScopes.length) {
						selectAllCheckbox.setChecked(true);
					}
				});

			}
		}).addStyleClass(sap.ui.commons.ButtonStyle.Default);
		// manageScopeButton.setTooltip("Select Project & Package")
		URLTxt.attachBrowserEvent('keyup', function(e) { // check key code
			if (e.which == 13)
				FinalNextButton.firePress();
		});

		jQuery.sap.require("jquery.sap.strings"); // Load the plugin to use

		var updateList = function(oListBox, sPrefix) {
			var oModel = new sap.ui.model.json.JSONModel();
			oListBox.setModel(oModel);

			// Destroy all existing items first
			var aScopes = filterScopes(sPrefix); // Find the scopes

			var oHL = new sap.ui.layout.HorizontalLayout();
			oHL.addContent(new sap.ui.commons.CheckBox({
				key : " {id}",
				checked : "{selected}",
				change : function() {
					selectAllCheckbox.setChecked(false);
					var counter = 0;
					var checkScopes = oVL.getModel().getData();
					checkScopes.forEach(function(scope, index) {
						if (scope.selected == false) {
							selectAllCheckbox.setChecked(false);
							return;
						} else {
							counter++;
						}
						if (counter == checkScopes.length) {
							selectAllCheckbox.setChecked(true);
						}
					})
				},
				value : "{description}"
			}));
			oHL.addContent(new sap.ui.commons.Label({
				text : "{id}",
				tooltip : "{description}"
			}).addStyleClass("scopelbl"));
			oListBox.bindAggregation("content", {
				path : "/",
				template : oHL
			});

			var jModel = new sap.ui.model.json.JSONModel();
			jModel.setData(aScopes);
			oListBox.setModel(jModel);
		};

		var filterScopes = function(sPrefix) {
			var aScopesOfPackage = selectedScopes;
			var aResult = [];
			for (var i = 0; i < aScopesOfPackage.length; i++) {
				if (!sPrefix
						|| sPrefix.length == 0
						|| jQuery.sap.startsWithIgnoreCase(
								aScopesOfPackage[i].id, sPrefix)) {
					aResult.push(aScopesOfPackage[i]);
				}
			}
			return aResult;
		};

		var fLayout4 = new sap.ui.layout.HorizontalLayout({
			content : [ scopeSearchText ]
		})

		var fLayout = new sap.ui.layout.VerticalLayout({
			content : [ fLayout4 ]
		});

		var popupCancelButton = new sap.ui.commons.Button({
			// press : [ buttonPopupCancelPressed, this ],
			press : function() {
				popUp.close()
			},
			text : "Cancel"

		}).addStyleClass(sap.ui.commons.ButtonStyle.Default);

		var okButton = new sap.ui.commons.Button({
			press : function() {
				constructScopeStr();
				popUp.close();
				oSearch.setValue("");
			},
			text : "Ok"

		}).addStyleClass(sap.ui.commons.ButtonStyle.Default);

		var buttonPopupCancelPressed = function() {
			// oDeferred.reject(); //promise fail
			popUp.close(); // dialog is hoisted from below
		};
		var buttonOkPressed = function() {
			popUp.close();
		};

		var popUp = new sap.ui.ux3.ToolPopup({
			title : "Manage Scopes",
			maxHeight : '300px',
			Width : '200px',
			modal : true,
			//                
			opener : manageScopeButton,

			buttons : [ okButton, popupCancelButton ]
		}).addStyleClass("popUpHeader");

		var scopeLbl = new sap.ui.commons.Label({
			text : "Scope",
			labelFor : scopeTxt
		});

		dLayout.createRow({
			height : "40px"
		}, scopeLbl, scopeTxt, manageScopeButton);

		var advButton = new sap.ui.commons.Button({
			text : "Advanced",
			tooltip : "Advanced Options",
			width : "75%",
			press : function() {
				advancedDialog.open();

			}
		});

		var advLayout = new sap.ui.commons.layout.MatrixLayout({
			layoutFixed : true,
			columns : 2,
			width : "100%",
			widths : [ "30%", "70%" ]
		});

		var oHeaderLbl = new sap.ui.commons.Label({
			text : "Header",
		// labelFor : oHeader
		});

		var oHeader = new sap.ui.commons.TextField({
			width : '80%',
			tooltip : "Header details for the YaaS end-point",
			value : {
				path : '/header',

				formatter : function(header) {
					var text = "";
					if (header)
						text = header;

					return text;
				}
			}
		});
		oHeader.attachBrowserEvent('keyup', function(e) { // check key code
			if (e.which == 13)
				advOkBtn.firePress();
		});

		oHeader.setPlaceholder("Header1=value1;Header2=value2");

		advLayout.createRow({
			height : "40%"
		}, oHeaderLbl, oHeader);

		var oQuerryParamLbl = new sap.ui.commons.Label({
			text : "Query Parameters"
		});

		var oQuerryParam = new sap.ui.commons.TextField({
			width : '80%',
			tooltip : "Filters/Query Parameters for the YaaS end-point",
			// value : "{/querryParam}"
			value : {
				path : '/querryParam',

				formatter : function(querryParam) {
					var text = "";
					if (querryParam)
						text = querryParam;

					return text;
				}
			}

		});
		oQuerryParam.attachBrowserEvent('keyup', function(e) { // check key code
			if (e.which == 13)
				advOkBtn.firePress();
		});

		oQuerryParam.setPlaceholder("param1=value1&param2=value2");

		advLayout.createRow({
			height : "40%"
		}, oQuerryParamLbl, oQuerryParam);

		var advOkBtn = new sap.ui.commons.Button({
			text : "OK",
			press : function() {

				var json = sap.ui.getCore().getModel();
				json.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);

				var querryParam = oQuerryParam.getValue();
				var header = oHeader.getValue();
				json.setProperty("/querryParam", querryParam);
				json.setProperty("/header", header);

				advancedDialog.close();
			}
		});
		var advCancelBtn = new sap.ui.commons.Button(
				{
					text : "Cancel",
					press : function() {
						var querryParam = sap.ui.getCore().getModel()
								.getProperty("/querryParam");

						var header = sap.ui.getCore().getModel().getProperty(
								"/header");
						if (querryParam != undefined)
							oQuerryParam.setValue(querryParam);
						if (header != undefined)
							oHeader.setValue(header);

						advancedDialog.close();
					}
				})

		var advancedDialog = new sap.ui.commons.Dialog({
			title : "Advanced",
			width : "30%",
			height : "30%",
			modal : true,
			resizable : false,
			content : [ advLayout ],
			buttons : [ advOkBtn, advCancelBtn ]

		});

		var testButton = new sap.ui.commons.Button({
			text : "Test",
			tooltip : "Test Connection",
			width : "75%",
			press : function() {
				var settingsDialog = sap.ui.getCore()
						.byId("yaasSettingsDialog");
				if (settingsDialog != undefined)
					settingsDialog.setBusy(true);
				var request = {};
				request.requestName = "testConnection";
				request.requestParams = [];
				request.url = URLTxt.getValue();
				request.scope = scopeTxt.getValue();
				request.header = oHeader.getValue();
				request.queryParameters = oQuerryParam.getValue();
				request.clientId = clientIdTxt.getValue();
				fServiceCall(JSON.stringify(request), function(response) {

					var json = JSON.parse(response);
					if (json.result == true) {
						sap.ui.commons.MessageBox.show(
								"Test Connection Successful",
								sap.ui.commons.MessageBox.Icon.SUCCESS);
					} else {

						sap.ui.commons.MessageBox.show(
								"Test Connection Failed\n" + json.errorMessage,
								sap.ui.commons.MessageBox.Icon.ERROR);

					}
					var settingsDialog = sap.ui.getCore().byId(
							"yaasSettingsDialog")
					if (settingsDialog != undefined)
						settingsDialog.setBusy(false);
				}, function(actionRequired, errorMessage, fullErrorObject) {
					sap.ui.commons.MessageBox.show(errorMessage,
							sap.ui.commons.MessageBox.Icon.ERROR);
					var settingsDialog = sap.ui.getCore().byId(
							"yaasSettingsDialog")
					if (settingsDialog != undefined)
						settingsDialog.setBusy(false);

				})

			}
		});

		var dButtonsLayout = new sap.ui.commons.layout.MatrixLayout({
			layoutFixed : true,
			columns : 4,
			width : "100%",
			widths : [ "25%", "25%", "25%", "25%" ]
		});
		dButtonsLayout.createRow({
			height : "30px"
		}, null);

		dButtonsLayout.createRow({
			height : "30px"
		}, advButton, testButton);
		/*
		 * Button press events
		 */
		var buttonCancelPressed = function() {
			oDeferred.reject();
			var YaasSettingsdialog = sap.ui.getCore()
					.byId("yaasSettingsDialog");
			if (YaasSettingsdialog != undefined)
				YaasSettingsdialog.close();
			var loginDialog = sap.ui.getCore().byId("loginDialog");
			if (loginDialog != undefined)
				loginDialog.close();
		};

		var buttonOKPressedAcc = function() {
			var settingsDialog = sap.ui.getCore().byId("yaasSettingsDialog");
			if (settingsDialog != undefined)
				settingsDialog.setBusy(true);
			var request = {};
			request.requestName = "validate";
			request.requestParams = [];
			var requestParam1 = {};
			request.url = URLTxt.getValue();
			request.scope = scopeTxt.getValue();
			request.header = oHeader.getValue();
			request.queryParameters = oQuerryParam.getValue();
			request.clientId = clientIdTxt.getValue();
			request.dataset = dataSetNameTxt.getValue();

			fServiceCall(JSON.stringify(request), function(response) {
				/*
				 * sap.ui.commons.MessageBox.alert(response);
				 */

				var json = JSON.parse(response);
				if (json.result == true) {
					var info = {};
					if (acquisitionState.info) {
						var json = JSON.parse(acquisitionState.info);
						info.username = json.username;
						info.proxy = json.proxy;
						info.password = json.password;
					}
					info.project = projectTxt.getLiveValue();
					info.packageName = packageTxt.getLiveValue();
					info.url = URLTxt.getValue();
					info.scope = scopeTxt.getValue();
					info.dataset = dataSetNameTxt.getValue();
					gDataSetName = info.dataset;
					info.header = oHeader.getValue();
					info.queryParameters = oQuerryParam.getValue();
					info.clientId = clientIdTxt.getValue();
					acquisitionState.info = JSON.stringify(info);
					oDeferred.resolve(acquisitionState, dataSetNameTxt
							.getValue());

					var YaasSettingsdialog = sap.ui.getCore().byId(
							"yaasSettingsDialog");
					if (YaasSettingsdialog != undefined) {
						YaasSettingsdialog.setBusy(false);
						YaasSettingsdialog.close();
					}
					var loginDialog = sap.ui.getCore().byId("loginDialog");
					if (loginDialog != undefined)
						loginDialog.close();
				} else {
					var YaasSettingsdialog = sap.ui.getCore().byId(
							"yaasSettingsDialog");
					if (YaasSettingsdialog != undefined) {
						YaasSettingsdialog.setBusy(false);
					}
					sap.ui.commons.MessageBox.show(json.message,
							sap.ui.commons.MessageBox.Icon.ERROR, "Error");
				}
			}, function(actionRequired, errorMessage, fullErrorObject) {
				var YaasSettingsdialog = sap.ui.getCore().byId(
						"yaasSettingsDialog");
				if (YaasSettingsdialog != undefined) {
					settingsDialog.setBusy(false);
				}
				sap.ui.commons.MessageBox.show(errorMessage,
						sap.ui.commons.MessageBox.Icon.ERROR);
			});
		};

		var buttonPreviousPressed = function() {

			sap.ui.getCore().getModel.setProperty("\packageList", []);
			sap.ui.getCORE().getModel.setProperty("\scopes", []);
			var YaasSettingsdialog = sap.ui.getCore()
					.byId("yaasSettingsDialog");
			if (YaasSettingsdialog != undefined)
				YaasSettingsdialog.close();

		};

		var PreviousButton = new sap.ui.commons.Button({
			press : [ buttonPreviousPressed, this ],
			text : "Previous",
			tooltip : "Previous",

		}).addStyleClass(sap.ui.commons.ButtonStyle.Default);

		var FinalNextButton = new sap.ui.commons.Button({
			press : [ buttonOKPressedAcc, this ],
			text : "Next",
			tooltip : "Next"

		}).setStyle(sap.ui.commons.ButtonStyle.Accept);

		var cancelButton = new sap.ui.commons.Button({
			press : [ buttonCancelPressed, this ],
			text : "Cancel",
			tooltip : "Cancel"
		}).addStyleClass(sap.ui.commons.ButtonStyle.Default);

		var onClosed = function() {
			if (oDeferred.state() === "pending") {
				this.destroy();
				oDeferred.reject();
			}
		};

		var envProperties = acquisitionState.envProps;
		if (acquisitionState.info) {
			var info = JSON.parse(acquisitionState.info);
			URLTxt.setValue(info.url);
			scopeTxt.setValue(info.scope);
			clientIdTxt.setValue(info.clientId);
			envProperties.datasetName = info.dataset;
			dataSetNameTxt.setValue(info.dataset);

		}

		/*
		 * Create the dialog
		 */
		var YaasSettingsdialog = sap.ui.getCore().byId("yaasSettingsDialog");
		if (YaasSettingsdialog == undefined)
			YaasSettingsdialog = new sap.ui.commons.Dialog(
					"yaasSettingsDialog", {
						width : "720px",
						height : "480px",
						modal : true,
						resizable : false,
						closed : function() {
							this.destroy();
							oDeferred.reject();
						},
						content : [ dLayout, dButtonsLayout ],
						buttons : [ /* PreviousButton, */FinalNextButton,
								cancelButton ]
					});
		YaasSettingsdialog.setBusy(true);
		YaasSettingsdialog.setTitle("YaaS Analytics");

		YaasSettingsdialog.open();

	};
	return LoginPage;
});
